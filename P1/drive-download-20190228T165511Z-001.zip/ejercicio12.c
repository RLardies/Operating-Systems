#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <math.h>

#define N 10

typedef struct {
  int x;
  int output;
}Args;

Args *power_2 (void *arg){

  Args *args = arg;

  args->output = pow(2, args->x);

  return args;
}

int main(int argc , char *argv[]) {

  pthread_t h[N];
  Args args[N];
  int i;

  for(i=0;i<N;i++){
    args[i].x = i;
    pthread_create(h + i, NULL, (void *) power_2, args + i);
  }

  for (i = 0; i < N; i++){

    pthread_join(h[i], NULL);
    printf ("El valor del hilo %d es: %d\n", i, args[i].output);
  }

  exit(EXIT_SUCCESS);
}
