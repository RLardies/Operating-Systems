/*
 * Ejemplo de codigo que genera un numero aleatorio y lo muestra por pantalla
 */
 #include <sys/types.h>
 #include <sys/wait.h>
 #include <time.h>
 #include <stdlib.h>
 #include <unistd.h>
 #include <stdio.h>

int main(int argc, char *argv[]) {
  

	pid_t pid1,pid2;
	int fd1[2],fd2[2];
 	int nbytes, pipe_status,buffer;
 	int r;

 	srand(time(NULL));
	

	pipe_status = pipe(fd1);
	if(pipe_status == -1){
		perror("Error creando la tuberia\n");
	}

	pipe_status = pipe(fd2);
	if(pipe_status == -1){
		perror("Error creando la tuberia\n");
	}

	if( (pid1 = fork()) == -1){
		perror("Error creando el proceso hijo\n");
		exit(EXIT_FAILURE);
	}

	if(pid1 == 0){
		close(fd2[0]);
		close(fd2[1]);
		close(fd1[0]);

		r = rand();
		printf("Este proceso ha generado el numero aleatorio: %d\n", r);

		write(fd1[1],&r,sizeof(r));
		exit(EXIT_SUCCESS);
	}

	if( (pid2 = fork()) == -1){
		perror("Error creando el segundo proceso hijo\n");
		exit(EXIT_FAILURE);
	}

	if(pid2 == 0){
		close(fd2[1]);
		close(fd1[1]);
		close(fd1[0]);

		read(fd2[0],&buffer,sizeof(buffer));

		printf("El numero leido en el hijo 2 es: %d\n",buffer);
		exit(EXIT_SUCCESS);
	}

	read(fd1[0],&buffer,sizeof(buffer));
	write(fd2[1],&buffer,sizeof(buffer));
	wait(NULL);
	wait(NULL);
	close(fd2[1]);
	close(fd1[0]);
 
  exit(EXIT_SUCCESS);
}
